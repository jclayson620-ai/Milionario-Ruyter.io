// ===== CONFIGURAÇÃO DO LINK DA HOTMART =====
// IMPORTANTE: Substitua 'SEU_LINK_HOTMART_AQUI' pelo seu link real da Hotmart
const HOTMART_LINK = 'https://hotmart.com/pt/marketplace/produtos/ganhos-inteligentes/SEU_LINK_AQUI';

// ===== INICIALIZAÇÃO DO DOCUMENTO =====
document.addEventListener('DOMContentLoaded', function() {
    setupHotmartLinks();
    setupMobileMenu();
    setupSmoothScroll();
    setupScrollAnimations();
});

// ===== CONFIGURAR LINKS DA HOTMART =====
function setupHotmartLinks() {
    // Selecionar todos os botões CTA
    const ctaButtons = document.querySelectorAll(
        '.btn-primary, .btn-secondary, #hotmart-btn'
    );

    ctaButtons.forEach(button => {
        // Se o botão não tiver um href específico, adicionar o link da Hotmart
        if (!button.hasAttribute('href') || button.getAttribute('href') === '#hotmart-link') {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                window.location.href = HOTMART_LINK;
            });
        }
    });

    // Configurar o botão específico de CTA final
    const hotmartBtn = document.getElementById('hotmart-btn');
    if (hotmartBtn) {
        hotmartBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.open(HOTMART_LINK, '_blank');
        });
    }
}

// ===== MENU MOBILE =====
function setupMobileMenu() {
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');

    if (hamburger) {
        hamburger.addEventListener('click', function() {
            navLinks.style.display = navLinks.style.display === 'flex' ? 'none' : 'flex';
            hamburger.classList.toggle('active');
        });

        // Fechar menu ao clicar num link
        const links = navLinks.querySelectorAll('a');
        links.forEach(link => {
            link.addEventListener('click', function() {
                navLinks.style.display = 'none';
                hamburger.classList.remove('active');
            });
        });
    }
}

// ===== SCROLL SUAVE =====
function setupSmoothScroll() {
    const links = document.querySelectorAll('a[href^="#"]');

    links.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            // Ignorar links para #hotmart-link
            if (href === '#hotmart-link') {
                return;
            }

            const target = document.querySelector(href);
            if (target) {
                e.preventDefault();
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// ===== ANIMAÇÕES AO FAZER SCROLL =====
function setupScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observar elementos para animação
    const animatedElements = document.querySelectorAll(
        '.benefit-card, .bonus-card, .testimonial-card, .pain-item'
    );

    animatedElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(20px)';
        element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(element);
    });
}

// ===== FUNÇÃO PARA ATUALIZAR O LINK DA HOTMART =====
// Use esta função para atualizar o link dinamicamente se necessário
function updateHotmartLink(newLink) {
    window.HOTMART_LINK = newLink;
    setupHotmartLinks();
    console.log('Link da Hotmart atualizado para:', newLink);
}

// ===== RASTREAMENTO DE EVENTOS (OPCIONAL) =====
// Se quiser rastrear cliques nos botões CTA
function trackCTAClick(buttonName) {
    console.log('CTA clicado:', buttonName);
    // Aqui você pode adicionar código para rastrear com Google Analytics, Mixpanel, etc.
    // Exemplo com Google Analytics:
    // gtag('event', 'cta_click', {
    //     'button_name': buttonName
    // });
}

// ===== VALIDAÇÃO DO LINK DA HOTMART =====
window.addEventListener('load', function() {
    if (HOTMART_LINK.includes('SEU_LINK_AQUI')) {
        console.warn('⚠️ AVISO: O link da Hotmart ainda não foi configurado!');
        console.warn('Por favor, substitua "SEU_LINK_HOTMART_AQUI" pelo seu link real.');
    } else {
        console.log('✅ Link da Hotmart configurado com sucesso:', HOTMART_LINK);
    }
});

// ===== FUNÇÃO AUXILIAR PARA COPIAR LINK =====
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert('Link copiado para a área de transferência!');
    }).catch(err => {
        console.error('Erro ao copiar:', err);
    });
}

// ===== CONTADOR DE REGRESSÃO (OPCIONAL) =====
// Se quiser adicionar um contador de tempo limitado
function startCountdown(endDate) {
    const countdownInterval = setInterval(() => {
        const now = new Date().getTime();
        const distance = endDate - now;

        if (distance < 0) {
            clearInterval(countdownInterval);
            console.log('Oferta expirada!');
            return;
        }

        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);

        console.log(`Tempo restante: ${days}d ${hours}h ${minutes}m ${seconds}s`);
    }, 1000);
}

// ===== FUNÇÃO PARA ABRIR MODAL COM INSTRUÇÕES =====
function showHotmartInstructions() {
    const instructions = `
    Para configurar o link da Hotmart:
    
    1. Aceda a https://hotmart.com
    2. Faça login na sua conta
    3. Vá para "Meus Produtos"
    4. Selecione o seu produto "Ganhos Inteligentes"
    5. Copie o link de venda (URL de checkout)
    6. Substitua "SEU_LINK_HOTMART_AQUI" no ficheiro js/script.js pelo seu link
    
    Exemplo de link:
    https://hotmart.com/pt/marketplace/produtos/ganhos-inteligentes/ABC123XYZ
    `;
    
    console.log(instructions);
    alert(instructions);
}

// ===== FUNÇÃO PARA VERIFICAR COMPATIBILIDADE DO NAVEGADOR =====
function checkBrowserCompatibility() {
    const requiredFeatures = [
        { name: 'Fetch API', test: () => typeof fetch !== 'undefined' },
        { name: 'LocalStorage', test: () => typeof localStorage !== 'undefined' },
        { name: 'IntersectionObserver', test: () => typeof IntersectionObserver !== 'undefined' }
    ];

    requiredFeatures.forEach(feature => {
        if (!feature.test()) {
            console.warn(`⚠️ Aviso: ${feature.name} não está disponível neste navegador.`);
        }
    });
}

// Executar verificação de compatibilidade
checkBrowserCompatibility();

// ===== FUNÇÃO PARA REGISTAR CONVERSÃO (OPCIONAL) =====
function logConversion(conversionType) {
    const timestamp = new Date().toISOString();
    const conversionData = {
        type: conversionType,
        timestamp: timestamp,
        userAgent: navigator.userAgent,
        referrer: document.referrer
    };

    console.log('Conversão registada:', conversionData);
    
    // Aqui você pode enviar dados para um servidor ou serviço de análise
    // Exemplo:
    // fetch('/api/conversions', {
    //     method: 'POST',
    //     headers: { 'Content-Type': 'application/json' },
    //     body: JSON.stringify(conversionData)
    // });
}

// ===== ESTILO PARA MENU MOBILE ATIVO =====
const style = document.createElement('style');
style.textContent = `
    @media (max-width: 768px) {
        .nav-links {
            display: none !important;
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            flex-direction: column;
            padding: 1rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            z-index: 999;
        }

        .nav-links.active {
            display: flex !important;
        }

        .hamburger.active span:nth-child(1) {
            transform: rotate(45deg) translate(8px, 8px);
        }

        .hamburger.active span:nth-child(2) {
            opacity: 0;
        }

        .hamburger.active span:nth-child(3) {
            transform: rotate(-45deg) translate(7px, -7px);
        }
    }
`;
document.head.appendChild(style);
