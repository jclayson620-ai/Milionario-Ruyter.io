# Landing Page - Ganhos Inteligentes

## 📋 Descrição

Esta é uma Landing Page profissional e responsiva para vender o Ebook **"Ganhos Inteligentes: Como Lucrar Online com Estratégias Simples e Rápidas"**.

A página foi desenvolvida com:
- **HTML5** semântico
- **CSS3** moderno e responsivo
- **JavaScript** vanilla para interatividade
- Design profissional com gradientes e animações
- Integração com a plataforma **Hotmart** para pagamentos

---

## 🚀 Como Usar

### 1. Estrutura de Ficheiros

```
ganhos_inteligentes_landing/
├── index.html          # Página principal
├── css/
│   └── style.css       # Estilos da página
├── js/
│   └── script.js       # Funcionalidades JavaScript
├── images/             # Pasta para imagens (opcional)
└── README.md           # Este ficheiro
```

### 2. Configurar o Link da Hotmart

**IMPORTANTE:** Antes de publicar a página, você precisa configurar o seu link de pagamento da Hotmart.

#### Passos:

1. **Aceda à Hotmart:**
   - Vá para https://hotmart.com
   - Faça login na sua conta

2. **Obtenha o Link do Produto:**
   - Vá para "Meus Produtos"
   - Selecione o produto "Ganhos Inteligentes"
   - Copie o link de venda (URL de checkout)
   - Exemplo: `https://hotmart.com/pt/marketplace/produtos/ganhos-inteligentes/ABC123XYZ`

3. **Configure o Link no Código:**
   - Abra o ficheiro `js/script.js`
   - Procure pela linha:
     ```javascript
     const HOTMART_LINK = 'https://hotmart.com/pt/marketplace/produtos/ganhos-inteligentes/SEU_LINK_AQUI';
     ```
   - Substitua `SEU_LINK_AQUI` pelo seu link real

4. **Salve o ficheiro**

---

## 🎨 Personalização

### Mudar Cores

As cores principais estão definidas no topo do ficheiro `css/style.css`:

```css
:root {
    --primary-color: #6366f1;        /* Cor principal (roxo) */
    --secondary-color: #ec4899;      /* Cor secundária (rosa) */
    --accent-color: #f59e0b;         /* Cor de destaque (laranja) */
    --dark-bg: #0f172a;              /* Fundo escuro */
    --light-bg: #f8fafc;             /* Fundo claro */
    --text-dark: #1e293b;            /* Texto escuro */
    --text-light: #64748b;           /* Texto claro */
}
```

Altere os valores hexadecimais para as cores que desejar.

### Mudar Textos

Todos os textos estão no ficheiro `index.html`. Procure pelas secções e edite conforme necessário:

- **Hero Section:** Título, subtítulo e CTA principal
- **Pain Section:** Problemas do público-alvo
- **Solution Section:** Apresentação do Ebook
- **Benefits Section:** Benefícios dos capítulos
- **Bonus Section:** Descrição dos bônus
- **Testimonials:** Depoimentos dos clientes
- **Guarantee:** Informações da garantia

### Adicionar Imagens

1. Coloque as imagens na pasta `images/`
2. No HTML, adicione:
   ```html
   <img src="images/sua-imagem.jpg" alt="Descrição">
   ```

---

## 📱 Responsividade

A página é totalmente responsiva e funciona em:
- ✅ Computadores (1200px+)
- ✅ Tablets (768px - 1199px)
- ✅ Telemóveis (até 767px)

---

## 🔗 Links Importantes

### Hotmart
- **Site:** https://hotmart.com
- **Documentação:** https://hotmart.com/pt/help

### Ferramentas Recomendadas
- **Hospedagem:** Netlify, Vercel, GitHub Pages
- **Domínio:** Namecheap, GoDaddy, Cloudflare
- **Email Marketing:** Mailchimp, LeadLovers, ActiveCampaign

---

## 📊 Análise e Rastreamento

### Google Analytics (Opcional)

Para adicionar rastreamento com Google Analytics:

1. Crie uma conta em https://analytics.google.com
2. Obtenha o seu ID de rastreamento
3. Adicione este código no `<head>` do `index.html`:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

Substitua `GA_MEASUREMENT_ID` pelo seu ID real.

### Pixel do Facebook (Opcional)

Para rastrear conversões no Facebook:

1. Crie um pixel em https://business.facebook.com
2. Adicione este código no `<head>` do `index.html`:

```html
<!-- Facebook Pixel -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  // ... código completo do pixel
}
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=SEU_PIXEL_ID&ev=PageView&noscript=1"
/></noscript>
```

---

## 🛠️ Desenvolvimento Local

### Executar Localmente

1. **Com Python 3:**
   ```bash
   python -m http.server 8000
   ```
   Depois aceda a `http://localhost:8000`

2. **Com Node.js (http-server):**
   ```bash
   npx http-server
   ```

3. **Com Live Server (VS Code):**
   - Instale a extensão "Live Server"
   - Clique com botão direito no `index.html` e selecione "Open with Live Server"

---

## 📝 Checklist de Publicação

Antes de publicar a página, verifique:

- [ ] Link da Hotmart configurado em `js/script.js`
- [ ] Textos revistos e personalizados
- [ ] Imagens adicionadas (se aplicável)
- [ ] Cores personalizadas (se desejado)
- [ ] Telemóvel testado (responsividade)
- [ ] Links testados (todos os botões CTA)
- [ ] Google Analytics configurado (opcional)
- [ ] Domínio configurado
- [ ] SSL/HTTPS ativado
- [ ] Teste de velocidade realizado

---

## 🐛 Resolução de Problemas

### O link da Hotmart não funciona
- Verifique se o link está correto em `js/script.js`
- Certifique-se de que o produto está publicado na Hotmart
- Teste o link diretamente no navegador

### A página não aparece responsiva
- Limpe o cache do navegador (Ctrl+Shift+Delete)
- Verifique se o ficheiro `css/style.css` está carregado
- Teste em modo incógnito

### Imagens não aparecem
- Verifique o caminho das imagens (deve ser `images/nome-da-imagem.jpg`)
- Certifique-se de que as imagens existem na pasta `images/`
- Verifique as permissões de ficheiros

---

## 📧 Suporte

Para dúvidas sobre a Landing Page, contacte o suporte ou consulte a documentação da Hotmart.

---

## 📄 Licença

Esta Landing Page foi criada para o Ebook "Ganhos Inteligentes" e é de uso exclusivo do proprietário.

---

## 🎯 Dicas de Conversão

1. **Mantenha a página rápida:** Comprima imagens, minimize CSS/JS
2. **Teste diferentes CTAs:** Experimente textos diferentes nos botões
3. **A/B Testing:** Teste cores, textos e layouts diferentes
4. **Mobile First:** Certifique-se de que a experiência mobile é excelente
5. **Confiança:** Adicione mais depoimentos e provas sociais
6. **Urgência:** Considere adicionar um contador regressivo
7. **Clareza:** Mensagens claras sobre o que o cliente vai receber

---

**Última atualização:** Novembro de 2025

**Versão:** 1.0
